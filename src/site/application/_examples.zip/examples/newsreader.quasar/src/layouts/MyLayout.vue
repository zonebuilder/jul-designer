<skip-template>
  <p>Layout page - imported via JUL Designer</p>
</skip-template>

<script>
import serialize from '../utils/serialize'
import instance from '../../../../projects/newsreader/quasar/layout'
import jul from 'jul'
import feeds from '../utils/feeds'

export default {
  name: 'MyLayout',
  template: serialize(instance),
  data () {
    // using the singleton state from 'utils/feeds.js'
    // for a new project, you should use Vuex instead
    return jul.apply(feeds.state, {
      drawerOpen: false,
      title: 'JUL News Reader'
    }, true)
  },
  methods: {
    onMenuClick () {
      this.drawerOpen = !this.drawerOpen
    },
    onNavigate (item) {
      if (!this.entries.length || item === 'home') {
        this.$router.push('/')
        return
      }
      if (item === 'next') {
        feeds.goNext()
        this.$router.push('/entry')
      }
      if (item === 'prev') {
        feeds.goNext(true)
        this.$router.push('/entry')
      }
    }
  }
}
</script>

<style>
</style>
