<skip-template>
  <p>Articles page - imported via JUL Designer</p>
</skip-template>

<script>
import serialize from '../utils/serialize'
import instance from '../../../../projects/newsreader/quasar/articles'
import jul from 'jul'
import feeds from '../utils/feeds'

export default {
  name: 'PageIndex',
  template: serialize(instance),
  data () {
    // using the singleton state from 'utils/feeds.js'
    // for a new project, you should use Vuex instead
    return jul.apply(feeds.state, {
      address: 'http://feeds.skynews.com/feeds/rss/technology.xml',
      entries: []
    }, true)
  },
  methods: {
    onGo () {
      feeds.go()
    },
    onArticleClick (id) {
      feeds.onSelectArticle(id)
      this.$router.push('/entry')
    }
  }
}
</script>
