<skip-template>
  <p>Entry page - imported via JUL Designer</p>
</skip-template>

<script>
import serialize from '../utils/serialize'
import instance from '../../../../projects/newsreader/quasar/entry'
import jul from 'jul'
import feeds from '../utils/feeds'

export default {
  name: 'PageEntry',
  template: serialize(instance),
  data () {
    // using the singleton state from 'utils/feeds.js'
    // for a new project, you should use Vuex instead
    return jul.apply(feeds.state, {
      entry: {
        title: '',
        link: '',
        pubDate: '',
        thumbnail: '',
        content: ''
      }
    }, true)
  },
  methods: {
  }
}
</script>
<style>
</style>
