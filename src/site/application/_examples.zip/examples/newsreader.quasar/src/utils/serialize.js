/* globals window, XMLSerializer */
import jul from 'jul'

const isBrowser = typeof window !== 'undefined' && window.location
const serializer = isBrowser && typeof XMLSerializer === 'function' ? new XMLSerializer() : null
const serialize = (dom) => {
  if (!dom) {
    return '<p><em>Empty DOM!</em></p>'
  }
  return serializer ? serializer.serializeToString(dom) : dom.xml || '<p><em>DNo DOM serialization!</em></p>'
}

export default (instance, parserConfig) => {
  if (typeof instance !== 'function') {
    return '<p><em>Empty UI instance function!</em></p>'
  }
  if (!isBrowser) {
    return '<p><em>DOM serialization not enabled outside a browser!</em></p>'
  }
  const project = instance(null)
  const parser = jul.parser(parserConfig || project.parserConfig)
  const dom = parser.create(project.ui)
  return serialize(dom)
}
