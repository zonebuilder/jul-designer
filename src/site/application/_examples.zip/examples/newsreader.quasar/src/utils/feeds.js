/* eslint-disable */
/* global feednami */
import jul from 'jul';

var oProject = jul.ns('newsreader.quasar');
export  default jul.apply(oProject.state ? null : {
/* begin business logic */
state: {
	// this state is shared with all the Vue components
	 title: 'JUL News Reader',
	address: 'http://feeds.skynews.com/feeds/rss/technology.xml',
	entries: [],
	entry: {},
	feed: null
},
go: function() {
	var sUrl = jul.trim(this.state.address);
	if (!(/^https?:\/\//).test(sUrl)) {
		window.alert('Address not valid!');
		return;
	}
	var oThis = this;
	feednami.loadPolyfills(function() {
		// feednami.setPublicApiKey('<-- API key required on a public web site -->');
		feednami.load(sUrl).then(jul.makeCaller(oThis, 'load'));
	});
},
load: function(oResult) {
  	if (oResult.error) {
	  	window.alert(oResult.error.message);
	  	return;
	  }
	  oResult = {feed: jul.apply(oResult, oResult.meta)};
	  if (oResult.feed && oResult.feed.entries) {
	  		oResult.feed.entries.sort(function(a, b) {
			  	return (new Date(b.pubDate)) - (new Date(a.pubDate));
			});
	  }
	  this.state.feed = oResult.feed;
	  	var sTitle = 'JUL News Reader';
	  if (oResult.feed && oResult.feed.title) {
	  	sTitle = oResult.feed.title.substr(0, 70) + ' - ' + sTitle;
	}
	this.state.title = sTitle;
	this.fillArticles();
},
encode: function(s) {
	return s.replace(/[<>&]/g, function(m) {
		switch (m) {
		case '<': return '&lt;';
		case '>': return '&gt;';
		case '&': return '&amp;';
		}
		return m;
	});
},
fillArticles: function() {
	this.state.entries = [];
	delete this.state.current;
	this.onSelectArticle();
	var oFeed = this.state.feed;
	if (!oFeed || !oFeed.entries) { return; }
	for (var i = 0; i < oFeed.entries.length; i++) {
		var oEntry = oFeed.entries[i];
		oEntry.id = 'entry-' + (i + 1);
		oEntry.title = oEntry.title[0] === '<' ? oEntry.title.split('>')[1].split('<')[0] : oEntry.title;
	}
	this.state.entries = oFeed.entries;
},
goNext: function(bPrev) {
	if (!this.state.feed || !this.state.feed.entries) { return; }
	var n = this.state.feed.entries.length;
	var k = this.state.current;
	if (k) { k = 1 + (n + (k - 1 + (bPrev ? -1 : 1)) % n) % n; }
	else { k = bPrev ? n : 1; }
	this.onSelectArticle('entry-' + k);
},
onSelectArticle: function(sId) {
	this.state.entry = {
		title: '',
		pubDate: '',
		thumbnail: '',
		content: ''
	};
	if (!sId) { return; }
	this.state.current = parseInt(sId.substr(6));
	var oEntry = this.state.feed.entries[this.state.current - 1];
	this.state.entry = {
		title: oEntry.title,
		link: oEntry.link,
		pubDate: (new Date(oEntry.pubDate)).toLocaleString(),
		thumbnail: (this.findImage(oEntry.thumbnail || oEntry.group || oEntry.image) || {}).url || '',
		content: ([].concat(oEntry.description)[0] || '').replace(/<a/gm, '<a target="_blank"')
	};
},
findImage: function(oMedia) {
	var oImage = false;
	if (!oMedia) { return oImage; }
	if (jul.typeOf(oMedia) === 'Array') {
		for (var i = oMedia.length - 1; i >= 0; i--) {
			oImage = this.findImage(oMedia[i]);
			if (oImage) { return oImage; }
		}
	}
	else if (typeof oMedia === 'object') {
		if (typeof oMedia.url === 'string' && (/^https?:\/\//).test(oMedia.url)) {
			return oMedia;
		}
		for (var sItem in oMedia) {
			if (oMedia.hasOwnProperty(sItem)) {
				oImage = this.findImage(oMedia[sItem]);
				if (oImage) { return oImage; }
			}
		}
	}
	return oImage;
}
/* end business logic */
});
