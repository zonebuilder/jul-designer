<template data-generated-from="(pckage_path)../../projects/newsreader/vuetify/articles.js">
  <v-container fluid>
    <v-row>
      <v-col />
      <v-col>
        <v-chip>
          Address
        </v-chip>
      </v-col>
      <v-col cols="8">
        <v-text-field v-model="address" dense @keypress.enter="onGo()" />
      </v-col>
      <v-col>
        <v-btn @click="onGo()">
          Go
        </v-btn>
      </v-col>
      <v-col />
    </v-row>
    <v-row>
      <v-col cols="12">
        <v-list>
          <v-list-item v-for="entry in entries" :key="entry.id" clickable @click="onArticleClick(entry.id)">
            <v-list-item-title>
              <h2>
                {{ entry.title }}
              </h2>
            </v-list-item-title>
          </v-list-item>
        </v-list>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import jul from 'jul'
import feeds from '../utils/feeds'

export default {
  data () {
    // using the singleton state from 'utils/feeds.js'
    // for a new project, you should use Vuex instead
    return jul.apply(feeds.state, {
      address: 'http://feeds.skynews.com/feeds/rss/technology.xml',
      entries: []
    }, true)
  },
  methods: {
    onGo () {
      feeds.go()
    },
    onArticleClick (id) {
      feeds.onSelectArticle(id)
      this.$router.push('/entry')
    }
  }
}
</script>
