<template data-generated-from="(pckage_path)../../projects/newsreader/vuetify/entry.js">
  <v-container fluid>
    <v-row>
      <v-col cols="12" style="text-align:center;">
        <h2>
          <a :href="entry.link" target="_blank">
            {{ entry.title }}
          </a>
        </h2>
        <p>
          {{ entry.pubDate }}
        </p>
        <div>
          <img :src="entry.thumbnail" width="50%" style="max-width:300px;">
        </div>
      </v-col>
    </v-row>
    <v-row>
      <v-col cols="12">
        <p>
          {{ entry.content }}
        </p>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import jul from 'jul'
import feeds from '../utils/feeds'

export default {
  data () {
    // using the singleton state from 'utils/feeds.js'
    // for a new project, you should use Vuex instead
    return jul.apply(feeds.state, {
      entry: {
        title: '',
        link: '',
        pubDate: '',
        thumbnail: '',
        content: ''
      }
    }, true)
  }
}
</script>
