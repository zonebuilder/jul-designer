<template data-generated-from="(pckage_path)../../projects/newsreader/vuetify/layout.js">
  <v-app>
    <v-navigation-drawer v-model="drawer" :clipped="clipped" :mini-variant="miniVariant" app fixed>
      <v-list>
        <v-list-item v-for="(item, i) in items" :key="i" :to="item.to" exact router>
          <v-list-item-action>
            <v-icon>
              {{ item.icon }}
            </v-icon>
          </v-list-item-action>
          <v-list-item-content>
            <v-list-item-title v-text="item.title" />
          </v-list-item-content>
        </v-list-item>
      </v-list>
    </v-navigation-drawer>
    <v-app-bar :clipped-left="clipped" app fixed>
      <v-app-bar-nav-icon @click="drawer = !drawer" />
      <v-toolbar-title style="width:100%;text-align:center;" v-text="title" />
      <v-btn outlined class="ma-2" @click="onNavigate('next')">
        Next
        <v-icon right>
          mdi-arrow-right
        </v-icon>
      </v-btn>
      <v-btn outlined class="ma-2" @click="onNavigate('prev')">
        Prev
        <v-icon right>
          mdi-arrow-left
        </v-icon>
      </v-btn>
      <v-btn outlined class="ma-2" @click="onNavigate('home')">
        Home
        <v-icon right>
          mdi-home
        </v-icon>
      </v-btn>
    </v-app-bar>
    <v-content>
      <nuxt />
    </v-content>
  </v-app>
</template>

<script>
import jul from 'jul'
import feeds from '../utils/feeds'

export default {
  data () {
    // using the singleton state from 'utils/feeds.js'
    // for a new project, you should use Vuex instead
    return jul.apply(feeds.state, {
      title: 'JUL News Reader',
      clipped: false,
      drawer: false,
      fixed: false,
      items: [
        {
          icon: 'mdi-format-list-bulleted',
          title: 'ARTICLES',
          to: '/'
        },
        {
          icon: 'mdi-account-card-details',
          title: 'ENTRY',
          to: '/entry'
        }
      ],
      miniVariant: false
    }, true)
  },
  methods: {
    onNavigate (item) {
      if (!this.entries.length || item === 'home') {
        this.$router.push('/')
        return
      }
      if (item === 'next') {
        feeds.goNext()
        this.$router.push('/entry')
      }
      if (item === 'prev') {
        feeds.goNext(true)
        this.$router.push('/entry')
      }
    }
  }
}
</script>
