/*
	JSVUE Convert version 1.0
	Copyright (c) 2019 The Zonebuilder <zone.builder@gmx.com>
	Licenses: GNU GPLv2 or later; GNU LGPLv3 or later (http://sourceforge.net/p/jul-designer/wiki/License/)
*/
/* eslint-disable */

const fs = require('fs');
const jul = require('jul');
const html = require('html-element');
var parse5 = require('parse5');
const serializer = require('xmlserializer');
const format = require('xml-beautifier');

const prjMap = {
	layout: 'layouts/default',
	articles: 'pages/index',
	entry: 'pages/entry'
};
const prjPath = '../../projects/newsreader/vuetify/';
const srcPath = './';

const realMap = {};
Object.keys(prjMap).forEach( function (item) {
	try {
		realMap[item] = {
			prj: fs.realpathSync(prjPath + item + '.js'),
			sfc: fs.realpathSync(srcPath + prjMap[item] + '.vue')
		};
	}
	catch (e) {}
});

const priorities = [
	'is',
	'v-for',
	'v-if,v-else-if,v-else,v-show,v-cloak',
	'v-pre,v-once',
	'id',
	'ref,key,slot',
	'v-model',
	'v-bind',
	'_other',
	'v-on',
	'v-html,v-text'
];
const rank = {};
priorities.forEach(function (item, i) {
	const a = item.split(',');
	a.forEach(function (val, j) {
		rank[val] = 10000 + 100 * i + j;
	});
});
const getRank = function (item) {
	const key = item.substr(0, 7) === 'v-bind:' ? item.substr(7) : item;
	return (item.substr(0, 5) === 'v-on:' ? rank['v-on'] :
		(key.length < item.length ? Math.min(rank['v-bind'], rank[key] || rank._other) :
		rank[item] || rank._other));
};
const cmpAttr = function (a, b) {
	return getRank(a.name) - getRank(b.name);
};
const order = function (node) {
	if (node.attrs) { node.attrs.sort(cmpAttr); }
	if (!node.childNodes) { return; }
	node.childNodes.forEach(order);
};

const re = /(\s)([\w\-:\.]+=\x22\x22|v-on:|v-bind:)/g;
const matcher = function (m, s1, s2) {
	if (s2.substr(0, 5) === 'v-on:') { m = s1 + '@' + s2.substr(5); }
	else if (s2.substr(0, 7) === 'v-bind:') { m = s1 + ':' + s2.substr(7); }
	if (s2.slice(-2) === '""') {
		const a = m.slice(0, -3);
		if (['id', 'class', 'style'].indexOf(a) < 0) { m = a; }
	}
	return m;
};
const reSelf = /<(area|base|br|col|embed|hr|img|input|link|meta|param|source|track|wbr)((\s|\S)*?)\/>/g;
const getTpl = function (prjName) {
	delete require.cache[realMap[prjName].prj];
	const prj = (require(realMap[prjName].prj))(null);
	const parser = jul.parser(prj.parserConfig);
	parser._domDocument = html.document;
	const el = html.document.createElement('div');
	parser.create(prj.ui, null, el);
	const root = parse5.parse(el.outerHTML);
	const node = root.childNodes[0].childNodes[1].childNodes[0];
	order(node);
	const xml = serializer.serializeToString(node);
	const tpl = format(xml, '  ').replace(re, matcher).replace(reSelf, '<$1$2>').replace(/style=\x22:;/g, 'style="')
		.replace(/&apos;/g, "'").replace(/\/>$/gm, ' />').trim().split('\n');
	tpl[0] = '<template data-generated-from="(pckage_path)' + prjPath + prjName + '.js">';
	tpl[tpl.length - 1] = '</template>';
	return tpl.join('\n');
};

const reTpl = /<template(\s|\S)+?<\/template\s??>/;
const writeTpl = function (prjName, tpl) {
	const content = fs.readFileSync(realMap[prjName].sfc, 'utf8');
	const hasTpl = /^\s*<template/.test(content);
	fs.writeFileSync(realMap[prjName].sfc, hasTpl ? content.replace(reTpl, tpl) : tpl + '\n\n' + content);
};

const build = function () {
	Object.keys(realMap).forEach(function (item) {
		console.log('Converting ' + item + ' ...');
		const tpl = getTpl(item);
		writeTpl(item, tpl);
	});
	console.log('.js -> .vue build done.');
};

const watch = function () {
	const chokidar = require('chokidar');
	chokidar.watch(prjPath + '*.js').on('change', function (path) {
		const prjName = path.replace(/\\/g, '/').split('/').pop().split('.js')[0];
		if (!realMap[prjName]) { return; }
		const tpl = getTpl(prjName);
		writeTpl(prjName, tpl);
		console.log('Synced ' + prjName + ' at ' + (new Date()).toLocaleString());
	});
	console.log('Watcher started at ' + (new Date()).toLocaleString());
};

switch (process.argv[2] || 'watch') {
case 'build': return build();
case 'watch': return watch();
default: return console.log('Allowed options: build, watch');
}

